const SCENICLIST =  [
  {
    id: "22",
    name: "苍岩山",
    position: [114.145831, 37.831976]
  },
  {
    id: "23",
    name: "徽州古城",
    position: [118.434598, 29.867]
  },
  {
    id: "24",
    name: "蓬莱",
    position: [120.752564, 37.825461]
  },
  {
    id: "25",
    name: "少林",
    position: [112.95978, 34.520026]
  },
  {
    id: "26",
    name: "神垕",
    position: [113.228142, 34.118356]
  },
  {
    id: "27",
    name: "云雾山",
    position: [114.214391, 31.12476]
  },
  {
    id: "35",
    name: "三孔",
    position: [116.989873, 35.590745]
  },
  {
    id: "66",
    name: "云冈石窟",
    position: [113.144103, 40.109236]
  }
]
export default SCENICLIST;